import '../styles/styles.css'

if (module.hot) {
  module.hot.accept()
}